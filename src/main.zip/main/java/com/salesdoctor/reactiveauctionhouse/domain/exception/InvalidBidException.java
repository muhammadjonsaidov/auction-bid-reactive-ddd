package com.salesdoctor.reactiveauctionhouse.domain.exception;

public class InvalidBidException extends RuntimeException {

    public InvalidBidException(String message) {
        super(message);
    }
}
